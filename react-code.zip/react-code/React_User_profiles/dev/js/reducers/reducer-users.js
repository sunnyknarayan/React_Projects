export default function(){
    return[
        {
            id:10,
            name:'Youtube',
            type:"streaming",
            description:"A streaming site",
            thumbnail:"https://cdnjs.cloudflare.com/ajax/libs/webicons/2.0.0/webicons/webicon-youtube.png"

        },
        {
            id:20,
            name:'Facebook',
            type:"social  site",
            description:"A socila networking site",
            thumbnail:"https://cdnjs.cloudflare.com/ajax/libs/webicons/2.0.0/webicons/webicon-facebook.png"

        },
        {
            id:30,
            name:'gmail',
            type:"mailing",
            description:"A mailing site",
            thumbnail:"https://cdnjs.cloudflare.com/ajax/libs/webicons/2.0.0/webicons/webicon-google-m.png"

        }

    ]
}