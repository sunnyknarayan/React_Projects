import React, {Component} from "react";
import {connect} from "react-redux";
class UserDetail extends Component{
    render(){
        return(
            <div>
            <img src={this.props.user.thumbnail}/>
            <h2>{this.props.user.name}</h2>
            <h4>{this.props.user.description}</h4>
            <h5>{this.props.user.type}</h5>
            </div>
        )
    }
}
function mapStateToProps(state){
    return{
        user:state.activeUser
    }
}
export default connect(mapStateToProps)(UserDetail);