export const selectUser = (user) => {
    console.log("you clciked on user : "+user.name);
    return{
        type:"USER_SELECTED",
        payload: user   //payload is data you are returning
    }
}