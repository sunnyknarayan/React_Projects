import React from "react";
import UserList from "../containers/user-list";
import UserDetails from '../containers/user-detail';

const App = () => (
    <div>
    <h3>user list</h3>
       <UserList/>
       <hr/>
       <UserDetails/>
    </div>
)

export default App;












