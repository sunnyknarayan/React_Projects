
# React/Sass/Redux



## Getting Started

To get started, first install all the necessary dependencies.
```
> npm install
```

np
```
> webpack
```

Start the development server (changes will now update live in browser)
```
> npm run start
```

To view your project, go to: [http://localhost:3000/](http://localhost:3000/)
